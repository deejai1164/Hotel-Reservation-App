package ui;
import api.AdminResource;
import model.IRoom;
import model.Room;
import model.RoomType;
import model.FreeRoom;
import java.util.Collections;
import java.util.Scanner;

public class AdminMenu {
    private static final AdminResource adminResource = AdminResource.getInstance();

    public static void startAdminMenu(Scanner scanner) {
        boolean keepRunning = true;

        while (keepRunning) {
            displayAdminMenu();
            String input = scanner.nextLine();

            if (input.length() == 1) {
                switch (input.charAt(0)) {
                    case '1': // See all Customers
                        System.out.println(adminResource.getAllCustomers());
                        break;
                    case '2': // See all Rooms
                        System.out.println(adminResource.getAllRooms());
                        break;
                    case '3': // See all Reservations
                        adminResource.displayAllReservations();
                        break;
                    case '4':
                        addRoom(scanner); // Call the helper method above
                        break;
                    case '5': // Back to Main Menu
                        keepRunning = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter 1-5.");
                }
            }
        }
    }

    private static void displayAdminMenu() {
        System.out.println("\n--- Admin Menu ---");
        System.out.println("1. See all Customers");
        System.out.println("2. See all Rooms");
        System.out.println("3. See all Reservations");
        System.out.println("4. Add a Room");
        System.out.println("5. Back to Main Menu");
        System.out.print("Please select an option: ");
    }

    private static void addRoom(Scanner scanner) {
        System.out.println("Enter room number:");
        String roomNumberInput = scanner.nextLine();
        if (roomNumberInput == null || roomNumberInput.trim().isEmpty()) {
            System.out.println("Room number cannot be empty.");
            return;
        }
        String roomNumber = roomNumberInput.trim();

        System.out.println("Enter price per night:");
        String priceInput = scanner.nextLine();
        double price;
        try {
            price = Double.parseDouble(priceInput);
        } catch (NumberFormatException ex) {
            System.out.println("Invalid price. Please enter a numeric value.");
            return;
        }
        if (price < 0) {
            System.out.println("Price cannot be negative.");
            return;
        }

        System.out.println("Enter room type: 1 for single bed, 2 for double bed:");
        String typeInput = scanner.nextLine().trim();
        RoomType roomType;
        if ("1".equals(typeInput)) {
            roomType = RoomType.SINGLE;
        } else if ("2".equals(typeInput)) {
            roomType = RoomType.DOUBLE;
        } else {
            System.out.println("Invalid! Enter valid room type (1 for SINGLE, 2 for DOUBLE)");
            return;
        }

        // Use Room or FreeRoom based on the price
        IRoom room;
        if (price == 0) {
            room = new FreeRoom(roomNumber, roomType);
        } else {
            room = new Room(roomNumber, price, roomType);
        }

        // Add the room to the system via the AdminResource
        try {
            adminResource.addRoom(Collections.singletonList(room));
            System.out.println("Room " + roomNumber + " added successfully!");
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
