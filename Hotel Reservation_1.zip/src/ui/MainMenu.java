package ui;

import api.HotelResource;
import model.IRoom;
import model.Reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {
    private static final HotelResource hotelResource = HotelResource.getInstance();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean keepRunning = true;

        while (keepRunning) {
            try {
                displayMenu();
                String input = scanner.nextLine();

                if (input.length() == 1) {
                    switch (input.charAt(0)) {
                        case '1': // Find and reserve a room
                            findAndReserveRoom(scanner);
                            break;
                        case '2': // See my reservations
                            seeMyReservations(scanner);
                            break;
                        case '3': // Create an account
                            createAccount(scanner);
                            break;
                        case '4': // Admin
                            AdminMenu.startAdminMenu(scanner); // Call the static method in AdminMenu
                            break;
                        case '5': // Exit
                            keepRunning = false;
                            break;
                        default:
                            System.out.println("Invalid choice. Please enter 1-5.");
                    }
                }
            } catch (Exception ex) {
                System.out.println("An unexpected error occurred. Returning to main menu.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\n--- Main Menu ---");
        System.out.println("1. Find and reserve a room");
        System.out.println("2. See my reservations");
        System.out.println("3. Create an account");
        System.out.println("4. Admin");
        System.out.println("5. Exit");
        System.out.print("Please select an option: ");
    }

    // Helper method to satisfy task 3: Create an account
    private static void createAccount(Scanner scanner) {
        System.out.print("Enter Email (name@domain.com): ");
        String email = scanner.nextLine();
        System.out.print("First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Last Name: ");
        String lastName = scanner.nextLine();

        try {
            hotelResource.createACustomer(email, firstName, lastName);
            System.out.println("Account created successfully!");
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getLocalizedMessage()); // Catches invalid email
        }
    }

    private static void findAndReserveRoom(Scanner scanner) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateFormat.setLenient(false);

        try {
            System.out.print("Enter your email (name@domain.com): ");
            String email = scanner.nextLine();

            if (hotelResource.getCustomer(email) == null) {
                System.out.println("No account found for that email. Please create an account first.");
                return;
            }

            System.out.print("Enter check-in date (dd/MM/yyyy): ");
            Date checkIn = parseDate(scanner.nextLine(), dateFormat);

            System.out.print("Enter check-out date (dd/MM/yyyy): ");
            Date checkOut = parseDate(scanner.nextLine(), dateFormat);

            // Disallow past check-in dates
            Date today = dateFormat.parse(dateFormat.format(new Date()));
            if (checkIn.before(today)) {
                System.out.println("Check-in date cannot be in the past.");
                return;
            }

            if (!checkOut.after(checkIn)) {
                System.out.println("Check-out date must be after check-in date.");
                return;
            }

            Collection<IRoom> availableRooms = hotelResource.findARoom(checkIn, checkOut);

            Date bookingCheckIn = checkIn;
            Date bookingCheckOut = checkOut;

            if (availableRooms.isEmpty()) {
                System.out.println("No rooms available for the selected dates.");
                Date recommendedCheckIn = addDays(checkIn, 7);
                Date recommendedCheckOut = addDays(checkOut, 7);

                Collection<IRoom> recommendedRooms = hotelResource.findRecommendedRooms(checkIn, checkOut);

                if (recommendedRooms.isEmpty()) {
                    System.out.println("No recommended rooms available 7 days later either.");
                    return;
                }

                System.out.println("Recommended rooms 7 days later (" +
                        dateFormat.format(recommendedCheckIn) + " to " +
                        dateFormat.format(recommendedCheckOut) + "):");
                for (IRoom room : recommendedRooms) {
                    System.out.println(room);
                }

                System.out.print("Would you like to book one of these recommended rooms? (Y/N): ");
                String answer = scanner.nextLine();
                if (!answer.equalsIgnoreCase("Y")) {
                    System.out.println("Reservation cancelled.");
                    return;
                }

                bookingCheckIn = recommendedCheckIn;
                bookingCheckOut = recommendedCheckOut;
                availableRooms = recommendedRooms;
            }

            System.out.println("Available rooms:");
            for (IRoom room : availableRooms) {
                System.out.println(room);
            }

            System.out.print("Enter room number to reserve (or press Enter to cancel): ");
            String roomNumber = scanner.nextLine();
            if (roomNumber.isEmpty()) {
                System.out.println("Reservation cancelled.");
                return;
            }

            IRoom selectedRoom = hotelResource.getRoom(roomNumber);
            if (selectedRoom == null) {
                System.out.println("Invalid room number.");
                return;
            }

            Reservation reservation = hotelResource.bookARoom(email, selectedRoom, bookingCheckIn, bookingCheckOut);
            System.out.println("Reservation created successfully:");
            System.out.println(reservation);

        } catch (ParseException e) {
            System.out.println("Invalid date format. Please use dd/MM/yyyy.");
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void seeMyReservations(Scanner scanner) {
        System.out.print("Enter your email (name@domain.com): ");
        String email = scanner.nextLine();

        if (hotelResource.getCustomer(email) == null) {
            System.out.println("No account found for that email.");
            return;
        }

        Collection<Reservation> reservations = hotelResource.getCustomersReservations(email);
        if (reservations.isEmpty()) {
            System.out.println("You have no reservations.");
        } else {
            System.out.println("Your reservations:");
            for (Reservation reservation : reservations) {
                System.out.println(reservation);
                System.out.println("--------------------------------------------------");
            }
        }
    }

    private static Date parseDate(String input, SimpleDateFormat dateFormat) throws ParseException {
        return dateFormat.parse(input.trim());
    }

    private static Date addDays(Date date, int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, days);
        return calendar.getTime();
    }
}
