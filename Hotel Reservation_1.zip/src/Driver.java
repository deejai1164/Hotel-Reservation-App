import model.Customer;
public class Driver {
    public static void main(String[] args) {
        // Test 1: Creating a valid customer
        Customer customer = new Customer("first", "second", "j@domain.com");
        System.out.println(customer);

        // Test 2: Testing the Email Validation (This should throw an exception)
        try {
            Customer invalidCustomer = new Customer("first", "second", "email");
        } catch (IllegalArgumentException ex) {
            System.out.println("Error caught as expected: " + ex.getLocalizedMessage());
        }
    }
}
