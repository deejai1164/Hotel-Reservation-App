package model;

public interface IRoom {
    public String getRoomNumber();  // Returns the unique room number
    public Double getRoomPrice();   // Returns the price per night
    public RoomType getRoomType();  // Returns SINGLE or DOUBLE
    public boolean isFree();        // Returns true if the room is free
}
