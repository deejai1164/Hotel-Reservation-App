package model;

/**
 * FreeRoom extends Room to handle rooms that have no cost.
 */
public class FreeRoom extends Room {

    public FreeRoom(String roomNumber, RoomType enumeration) {
        // The 'super' call passes 0.0 as the price to the Room constructor
        super(roomNumber, 0.0, enumeration);
    }

    @Override
    public String toString() {
        return "Free Room - Number: " + getRoomNumber() +
                " | Type: " + getRoomType() + " | Price: Free";
    }
}
