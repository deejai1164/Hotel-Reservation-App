package api;
import model.Customer;
import model.IRoom;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.List;
public class AdminResource {
    // 1. Provide a static reference for the Singleton pattern
    private static final AdminResource INSTANCE = new AdminResource();

    // Access the single instances of the backend services
    private final CustomerService customerService = CustomerService.getInstance();
    private final ReservationService reservationService = ReservationService.getInstance();

    // Private constructor ensures only one instance exists
    private AdminResource() {}

    // Static method to get the single instance
    public static AdminResource getInstance() {
        return INSTANCE;
    }

    /**
     * Retrieves a specific customer by email.
     */
    public Customer getCustomer(String email) {
        return customerService.getCustomer(email);
    }

    /**
     * Adds a list of rooms to the system.
     */
    public void addRoom(List<IRoom> rooms) {
        for (IRoom room : rooms) {
            reservationService.addRoom(room);
        }
    }

    /**
     * Retrieves a collection of all rooms in the hotel.
     */
    public Collection<IRoom> getAllRooms() {
        return reservationService.getAllRooms();
    }

    /**
     * Retrieves a collection of all customer accounts.
     */
    public Collection<Customer> getAllCustomers() {
        return customerService.getAllCustomers();
    }

    /**
     * Prints all existing reservations to the console.
     */
    public void displayAllReservations() {
        reservationService.printAllReservation();
    }
}
