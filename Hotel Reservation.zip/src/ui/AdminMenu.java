package ui;
import api.AdminResource;
import model.IRoom;
import model.Room;
import model.RoomType;
import model.FreeRoom;
import java.util.Collections;
import java.util.Scanner;

public class AdminMenu {
    private static final AdminResource adminResource = AdminResource.getInstance();

    public static void startAdminMenu(Scanner scanner) {
        boolean keepRunning = true;

        while (keepRunning) {
            displayAdminMenu();
            String input = scanner.nextLine();

            if (input.length() == 1) {
                switch (input.charAt(0)) {
                    case '1': // See all Customers
                        System.out.println(adminResource.getAllCustomers());
                        break;
                    case '2': // See all Rooms
                        System.out.println(adminResource.getAllRooms());
                        break;
                    case '3': // See all Reservations
                        adminResource.displayAllReservations();
                        break;
                    case '4':
                        addRoom(scanner); // Call the helper method above
                        break;
                    case '5': // Back to Main Menu
                        keepRunning = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter 1-5.");
                }
            }
        }
    }

    private static void displayAdminMenu() {
        System.out.println("\n--- Admin Menu ---");
        System.out.println("1. See all Customers");
        System.out.println("2. See all Rooms");
        System.out.println("3. See all Reservations");
        System.out.println("4. Add a Room");
        System.out.println("5. Back to Main Menu");
        System.out.print("Please select an option: ");
    }

    private static void addRoom(Scanner scanner) {
        System.out.println("Enter room number:");
        String roomNumber = scanner.nextLine();

        System.out.println("Enter price per night:");
        Double price = Double.parseDouble(scanner.nextLine());

        System.out.println("Enter room type: 1 for single bed, 2 for double bed:");
        // Simple logic to convert 1/2 into the RoomType enum
        RoomType roomType = scanner.nextLine().equals("1") ? RoomType.SINGLE : RoomType.DOUBLE;

        // Use Room or FreeRoom based on the price
        IRoom room;
        if (price == 0) {
            room = new FreeRoom(roomNumber, roomType);
        } else {
            room = new Room(roomNumber, price, roomType);
        }

        // Add the room to the system via the AdminResource
        adminResource.addRoom(Collections.singletonList(room));
        System.out.println("Room " + roomNumber + " added successfully!");
    }
}
