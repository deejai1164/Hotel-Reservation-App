package service;
import model.Customer;
import model.IRoom;
import model.Reservation;
import java.util.*;
public class ReservationService {
    // Static reference for Singleton pattern
    private static final ReservationService INSTANCE = new ReservationService();

    // Collections to store rooms and reservations
    private final Map<String, IRoom> rooms = new HashMap<>();
    private final Set<Reservation> reservations = new HashSet<>();

    private ReservationService() {}

    public static ReservationService getInstance() {
        return INSTANCE;
    }

    public void addRoom(IRoom room) {
        rooms.put(room.getRoomNumber(), room);
    }

    public IRoom getARoom(String roomId) {
        return rooms.get(roomId);
    }

    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        // Prevent double-booking: check for overlapping reservations on the same room
        for (Reservation existing : reservations) {
            if (existing.getRoom().equals(room) &&
                    datesOverlap(existing.getCheckInDate(), existing.getCheckOutDate(), checkInDate, checkOutDate)) {
                throw new IllegalArgumentException("Room is already booked for these dates.");
            }
        }

        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservation);
        return reservation;
    }

    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        // Start with all rooms, then remove any that are already reserved for the given dates
        List<IRoom> availableRooms = new ArrayList<>(rooms.values());

        for (Reservation reservation : reservations) {
            if (datesOverlap(reservation.getCheckInDate(), reservation.getCheckOutDate(), checkInDate, checkOutDate)) {
                availableRooms.remove(reservation.getRoom());
            }
        }

        return availableRooms;
    }

    /**
     * Searches for recommended rooms by shifting the requested dates by +7 days
     * and re-using the availability logic.
     */
    public Collection<IRoom> findRecommendedRooms(Date checkInDate, Date checkOutDate) {
        Date recommendedCheckIn = addDays(checkInDate, 7);
        Date recommendedCheckOut = addDays(checkOutDate, 7);
        return findRooms(recommendedCheckIn, recommendedCheckOut);
    }

    public Collection<Reservation> getCustomersReservation(Customer customer) {
        List<Reservation> customerReservations = new ArrayList<>();
        for (Reservation reservation : reservations) {
            if (reservation.getCustomer().equals(customer)) {
                customerReservations.add(reservation);
            }
        }
        return customerReservations;
    }

    /**
     * Helper to determine if two date ranges overlap.
     */
    private boolean datesOverlap(Date start1, Date end1, Date start2, Date end2) {
        return start1.before(end2) && end1.after(start2);
    }

    /**
     * Helper to add a number of days to a date.
     */
    private Date addDays(Date date, int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, days);
        return calendar.getTime();
    }

    public void printAllReservation() {
        if (reservations.isEmpty()) {
            System.out.println("No reservations found.");
        } else {
            for (Reservation reservation : reservations) {
                System.out.println(reservation);
            }
        }
    }

    // Helper method for the Admin menu
    public Collection<IRoom> getAllRooms() {
        return rooms.values();
    }
}
