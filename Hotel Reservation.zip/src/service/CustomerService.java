package service;
import model.Customer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
public class CustomerService {
    // 1. Provide a static reference for the Singleton pattern
    private static final CustomerService INSTANCE = new CustomerService();

    // The collection used to manage (remember) customer information
    private final Map<String, Customer> customers = new HashMap<>();

    // Private constructor ensures there is only one of this service
    private CustomerService() {}

    // Static method to get the single instance of this service
    public static CustomerService getInstance() {
        return INSTANCE;
    }

    /**
     * Creates a new customer and adds them to the collection
     */
    public void addCustomer(String email, String firstName, String lastName) {
        Customer newCustomer = new Customer(firstName, lastName, email);
        customers.put(email, newCustomer);
    }

    /**
     * Retrieves a customer based on their unique email
     */
    public Customer getCustomer(String customerEmail) {
        return customers.get(customerEmail);
    }

    /**
     * Returns a collection of all registered customers
     */
    public Collection<Customer> getAllCustomers() {
        return customers.values();
    }
}
